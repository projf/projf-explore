# Nexys Video Bitstreams

This folder contains Nexys Video bitstreams built with Vivado 2022.2.

I use these for video recording, but you can use them to program your Nexys Video board without having to build from source.
